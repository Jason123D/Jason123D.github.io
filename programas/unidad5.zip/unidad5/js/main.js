const datos = {
    persona: {},
    familiares: [],
    condiciones: [],
    internamientos: []
  };